# test/unit/__init__.py
#

'''
This subpackage contains modules for unit testing C-PAC
'''