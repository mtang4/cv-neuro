Easy thresh
==============

.. automodule:: CPAC.easy_thresh
    :members:
