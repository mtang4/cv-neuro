Timeseries Analysis
===================

.. automodule:: CPAC.timeseries
    :members:
