Regional Homogeneity Approach to fMRI data analysis
===================================================

.. automodule:: CPAC.reho
    :members:
