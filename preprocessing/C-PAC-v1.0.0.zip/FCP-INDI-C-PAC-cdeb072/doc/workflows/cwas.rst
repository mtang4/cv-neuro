Connectome Wide Association Studies
===================================

.. automodule:: CPAC.cwas
    :members:

