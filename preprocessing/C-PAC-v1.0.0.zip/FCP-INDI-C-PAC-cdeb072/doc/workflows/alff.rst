Amplitude of Low Frequency Fluctuations(ALFF) and fractional ALFF
=================================================================

.. automodule:: CPAC.alff
    :members:
